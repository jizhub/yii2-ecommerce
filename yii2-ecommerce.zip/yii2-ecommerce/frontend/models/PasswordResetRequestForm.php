<?php
namespace frontend\models;

/**
 * Password reset request form
 */
class PasswordResetRequestForm extends \common\models\PasswordResetRequestForm
{
}
