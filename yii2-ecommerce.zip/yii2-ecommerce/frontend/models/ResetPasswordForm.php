<?php
namespace frontend\models;

/**
 * Password reset form
 */
class ResetPasswordForm extends \common\models\ResetPasswordForm
{
}
